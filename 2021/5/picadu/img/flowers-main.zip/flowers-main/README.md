# flowers — учебный проект Glo Academy 
### Выполнил проект: Иван Иванов 

## Технологии
- HTML 
- CSS 
- Bootstrap 
- jQuery 
- Fancybox 
- Swiper Slider JS 
